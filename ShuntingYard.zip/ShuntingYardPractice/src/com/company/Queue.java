package com.company;

import java.util.ArrayList;

public class Queue {

    private ArrayList<String> queue = new ArrayList<String>();

    public Queue(){

    }

    public void enqueue(String s){
        queue.add(s);
    }

    public String dequeue(){
        String first = queue.get(0);
        queue.remove(0);
        return first;
    }

    public String dequeueAll(){
        StringBuilder expression = new StringBuilder();

        for (String e : queue) {
            expression.append(queue);
        }


        return expression.toString();
    }

    public void clear(){
        for (String e : queue) {
            queue.remove(queue.size() - 1);
        }
    }

    @Override
    public String toString(){
        StringBuilder expression = new StringBuilder();

        for (String e :
                queue) {
            expression.append(e);
        }

        return expression.toString();
    }

}
