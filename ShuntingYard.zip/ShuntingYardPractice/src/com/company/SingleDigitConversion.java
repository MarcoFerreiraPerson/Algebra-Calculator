package com.company;
public class SingleDigitConversion {


    private static boolean isNumeric(String c) {
        try {
            int integer = Integer.parseInt(String.valueOf(c));
        } catch (NumberFormatException nfe) {
            return false;
        }

        return true;
    }


    private static boolean isTen(String expression) {
        for (int i = 0; i < expression.length()-1; i++)
            if ((isNumeric(String.valueOf(expression.charAt(0))) && isNumeric(String.valueOf(expression.charAt(1)))) || isNumeric(String.valueOf(expression.charAt(i))) && isNumeric(String.valueOf(expression.charAt(i + 1)))) {
                return true;
            }

        return false;
    }

    private static int findOperatorIndex(int index, String expression) {

        for (int i = index+1; i < expression.length(); i++) {
            if (!isNumeric(String.valueOf(expression.charAt(i)))){
                return i;
            }
        }

        return expression.length();
    }

    private static int getNumericIndex(String expression) {
        for (int i = 0; i < expression.length()-1; i++) {
            if (isNumeric(String.valueOf(expression.charAt(i))) && isNumeric(String.valueOf(expression.charAt(i+1)))){
                return i;
            }
        }

        return -1;
    }

    private static String convert(String num){
        int target = Integer.parseInt(num);
        int evaluated = 0;
        StringBuilder newExpression = new StringBuilder("(");

        while (target != evaluated){
            if (evaluated + 9 <= target){
                evaluated += 9;
                newExpression.append("9");
                if (evaluated != target){
                    newExpression.append("+");
                }
            }
            else{
                for (int i = 8; i > 0; i--) {
                    if (evaluated + i == target){
                        newExpression.append(i);
                        return String.valueOf(newExpression.append(")"));
                    }
                }
            }
        }

        return String.valueOf(newExpression.append(")"));
    }

    public static String singleDigitConvert(String expression){
        String firstHalf;
        String newExpression;
        int numericIndex = 0;

        while (isTen(expression)) {
            if (isNumeric(String.valueOf(expression.charAt(0))) && isNumeric(String.valueOf(expression.charAt(1)))) {

                firstHalf = expression.substring(numericIndex, findOperatorIndex(numericIndex, expression));
                expression = expression.substring(findOperatorIndex(numericIndex, expression));

                firstHalf = convert(firstHalf);

                expression = firstHalf + expression;

                numericIndex = getNumericIndex(expression);
            }

            else if (isTen(expression) && numericIndex != -1){
                numericIndex = getNumericIndex(expression);

                firstHalf = expression.substring(0, numericIndex);
                expression = expression.substring(numericIndex);

                newExpression = expression.substring(0,findOperatorIndex(0, expression));
                expression = expression.substring(findOperatorIndex(0, expression));

                newExpression = convert(newExpression);

                expression = firstHalf + newExpression + expression;

                numericIndex = getNumericIndex(expression);
            }

        }

        return expression;
    }




}
