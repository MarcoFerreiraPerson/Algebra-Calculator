package com.company;

import com.company.ShuntingYardAlgorithm;

import java.util.HashMap;
import java.util.Objects;

import static java.lang.System.out;

public class TestShuntingYard {

    public static void invoke(){

        HashMap<String, String> expressions = new HashMap<>();

        expressions.put("4+8*3", "483*+");                                      // basic pemdas case
        expressions.put("9+4+6*(0-9)", "94+609-*+");                            // testing negative numbers
        expressions.put("((9+9)/3)^2+(((9+4)+7)*5^2)", "99+3/2^94+7+52^*+");    // testing complex problems with some being 2 digits
        expressions.put("(9+9+9+9+9+9+9+9+9+9)+(0-(9+9+9+9+9+8))*(0-(9+9+9+9+9+9+9+9+1))", "99+9+9+9+9+9+9+9+9+099+9+9+9+8+-099+9+9+9+9+9+9+1+-*+");  // testing double digit negative numbers
        expressions.put("1", "1");
        expressions.put("-1", "01-");

        int count = 1;
        for (String expression : expressions.keySet()){
            if (Objects.equals(ShuntingYardAlgorithm.infixToPostfix(expression), expressions.get(expression))){
                out.println("Test " + count + "\t(" + expression + "):\t" + "\u001B[42m" + "PASSED" + "\u001B[0m");
                count++;
                continue;
            }

            out.println("Test " + count + "\t(" + expression + "):\t" + "\u001B[41m" + "FAILED" + "\u001B[0m");

            out.println("\nEXPECTED: " + expressions.get(expression));
            out.println("RECEIVED: " + ShuntingYardAlgorithm.infixToPostfix(expression) + "\n");

            count++;

        }
    }


}
