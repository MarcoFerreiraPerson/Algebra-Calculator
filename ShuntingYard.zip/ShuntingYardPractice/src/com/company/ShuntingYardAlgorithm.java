package com.company;

import java.util.Stack;

public class ShuntingYardAlgorithm {

    private static boolean isOperator(String token) {

        switch(token){
            case "+":
            case "-":
            case "*":
            case "/":
                return true;
            default:
                return false;
        }

    }


    private static int  getPrecidence(String stackPeek) {
        switch (stackPeek){
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;
            case "^":
                return 3;
            default:
                return -1;
        }


    }


    private static boolean isNumeric(String c){
        try{
            int integer = Integer.parseInt(String.valueOf(c));
        }catch (NumberFormatException nfe){
            return false;
        }

        return true;
    }


    public static String infixToPostfix(String expression){
        Stack<String> stack = new Stack<>();
        Queue queue = new Queue();

        expression = expression.replaceAll(" ", "");

        expression = InfixConverter.convertNegative(expression);
        expression = SingleDigitConversion.singleDigitConvert(expression);


        for (int i = 0; i < expression.length(); i++) {

            if (isNumeric(String.valueOf(expression.charAt(i)))){
                queue.enqueue(String.valueOf(expression.charAt(i)));
            }

            else if (expression.charAt(i) == '('){
                stack.push(String.valueOf(expression.charAt(i)));
            }

            else if (expression.charAt(i) == ')'){
                while(!stack.empty() && (!stack.peek().equals("("))){
                    queue.enqueue(stack.pop());
                }
                stack.pop();
            }

            else {
                while ((!stack.empty()) && (getPrecidence(String.valueOf(expression.charAt(i))) <= getPrecidence(stack.peek()) && isOperator(String.valueOf(expression.charAt(i))))) {
                    queue.enqueue(stack.pop());
                }
                stack.push(String.valueOf(expression.charAt(i)));
            }

        }

        while(!stack.empty()) queue.enqueue(stack.pop());

        return queue.toString();
    }




}
