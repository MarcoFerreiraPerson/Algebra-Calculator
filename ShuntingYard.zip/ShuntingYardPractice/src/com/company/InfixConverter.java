package com.company;

public class InfixConverter {

    private static boolean isNumeric(String c){
        try{
            int integer = Integer.parseInt(String.valueOf(c));
        }catch (NumberFormatException nfe){
            return false;
        }

        return true;
    }

    private static boolean isNegative(String expression) {
        for (int i = 0; i < expression.length(); i++) {
            if ((expression.charAt(0) == '-') || (expression.charAt(i) == '-' && !isNumeric(String.valueOf(expression.charAt(i-1)))))
                return true;
        }

        return false;
    }

    private static int findOperatorIndex(int index, String expression) {

        for (int i = index+1; i < expression.length(); i++) {
            if (!isNumeric(String.valueOf(expression.charAt(i)))){
               return i;
            }
        }

        return expression.length();
    }

    private static int getNegativeIndex(String expression) {
        for (int i = 1; i < expression.length(); i++) {
            if (expression.charAt(i) == '-' && !isNumeric(String.valueOf(expression.charAt(i - 1)))){
                return i;
            }
        }
        return -1;
    }

    public static String convertNegative(String expression){

        String firstHalf;
        String newExpression;
        

        int negativeIndex = 0;

        while (isNegative(expression)){
            if (expression.charAt(0) == '-'){
                negativeIndex = 0;

                firstHalf = expression.substring(negativeIndex, findOperatorIndex(negativeIndex, expression));
                expression = expression.substring(findOperatorIndex(negativeIndex, expression));

                newExpression = "(0" + firstHalf + ")";

                expression = newExpression + expression;

                negativeIndex = getNegativeIndex(expression);
            }

            else if (expression.contains("-") && negativeIndex != -1){
                negativeIndex = getNegativeIndex(expression);

                firstHalf = expression.substring(0, negativeIndex);
                expression = expression.substring(negativeIndex);


                newExpression = expression.substring(0, findOperatorIndex(0, expression));
                expression = expression.substring(findOperatorIndex(0, expression));

                newExpression = "(0" + newExpression + ")";

                expression = firstHalf + newExpression + expression;

                negativeIndex = getNegativeIndex(expression);
            }
        }

        return expression;
    }




}